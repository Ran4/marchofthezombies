MAX_ZOMBIES = 300 #spawning this many zombies will take about 23 minutes
FAST_ZOMBIE_SPAWN = 180 #every 3 seconds
SLOW_ZOMBIE_SPAWN = 300 #every 5 seconds
TIME_TIL_FASTER_ZOMBIE_SPAWN = 2*60*60 #2 minutes

MAX_ITEM_QUEUE = 15
ITEM_RESPAWNTIME = 420 #7 seconds

AIR_FRICTIION = 0.996 #used when throwing records
GRAVITY = 0.02