Compile using python + pygame
Game was compiled in python 2.5 with pygame 1.8.1
Remember to copy the "data" folder to the src/ folder if you wish to run the game directly from MLD_10.py