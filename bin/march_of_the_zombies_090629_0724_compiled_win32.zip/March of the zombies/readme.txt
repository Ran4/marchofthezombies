You are the lone survivor of... Uh, an zombie attack.
Stay alive for as long as possible! Beat your record!

Aim for the head for massive damage, shoot to the body to slow Zombie down and shoot to the legs to cripple them.
Don't forget to conserve ammo!


Controls: A/D for movement, W or S for moving up stairs/ladders (hold down when you want to use a stairway/ladder), mouse1 fires pistol, mouse2 throws records, ESC quits, enter toggles fullscreen (800*600 pixels only)


Bonus controls: F prints fps, C counts all the zombies and prints their types to console, N adds MAX_ZOMBIES zombies (300), M adds one zombie, K kills all zombies that aren�t roaming (only zombie dogs can roam)




Licensed under Creative Commons 2.5 BY-SA
http://creativecommons.org/licenses/by-sa/2.5/se/deed.en

You are free:
    * to Share � to copy, distribute and transmit the work
    * to Remix � to adapt the work

Under the following conditions:
    *Attribution � You must attribute the work in the manner specified by the author or licensor (but not in any way that suggests that they endorse you or your use of the work).
    *Share Alike � If you alter, transform, or build upon this work, you may distribute the resulting work only under the same or similar license to this one.